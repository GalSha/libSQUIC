Test for MATLAB interface for CXSparse.  Type "testall" to run all the tests.

Also includes "textbook" codes for the book "Direct Methods for Sparse Linear
Systems", which are not part of CXSparse proper, but are used in the tests.

Timothy A. Davis, http://www.suitesparse.com
